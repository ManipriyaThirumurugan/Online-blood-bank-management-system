package com.obbs.controller;

import java.util.ArrayList;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.obbs.service.UsersService;
import com.obbs.model.DonorPojo;
import com.obbs.model.FeedbackPojo;
import com.obbs.model.PostBloodRequirementPojo;
import com.obbs.model.RecipientPojo;
import com.obbs.model.SlotBookingPojo;
import com.obbs.model.UsersPojo;

@Controller
public class UsersController {

	@Autowired
	UsersService usersService;

	@RequestMapping("/registerUsers")

	public ModelAndView addUsers(@ModelAttribute("command") UsersPojo usersPojo, BindingResult result) {
		int id;
		id = usersService.registerUser(usersPojo);
		ModelAndView mav = new ModelAndView("Login");
        mav.addObject("message","Successfully Registered now you can log in "); 
		if (id == 1) {
			return mav;
		} else {
			return new ModelAndView("Error");
		}

	}

	@RequestMapping("/recipientLogin")

	public ModelAndView loginUsers(@ModelAttribute("command") UsersPojo usersPojo, BindingResult result) {
		int login;
		login = usersService.loginUser(usersPojo);
		ModelAndView mav = new ModelAndView("Login");
        mav.addObject("error","Invalid credentials!Try again"); 
		if (login == 1) {
			return new ModelAndView("BloodRequirement");
		} else {
			return mav;
		}

	}

	@RequestMapping("/donorRequests")

	public ModelAndView donorRequests(@ModelAttribute("command") DonorPojo donorPojo, BindingResult result) {
		int id;
		id = usersService.registerDonor(donorPojo);
		ModelAndView mav = new ModelAndView();
        
		if (id == 1) {
			mav.addObject("d_msg","Successfully registered as a donor"); 
			mav = new ModelAndView("DonorLogin");
			
		} else {
			mav.addObject("d_msg","Fill the missed fields"); 
			//return new ModelAndView("DonorRegister");
			
		}
return mav;
	}
	

	@RequestMapping("/recipientRequests")

	public ModelAndView recipientRequests(@ModelAttribute("recipient") RecipientPojo recipientPojo,
			BindingResult result, HttpServletRequest request, HttpServletResponse response) {

		List<DonorPojo> details = new ArrayList<DonorPojo>();
		details = usersService.donorCheck(recipientPojo);
		request.setAttribute("details", details);

		if (!details.isEmpty()) {
			return new ModelAndView("DonorDetails");
		} else {
			ModelAndView mav = new ModelAndView("BloodRequirement");
			mav.addObject("donornotfound","No donor found.Click here to post your requirement");
			return mav;
		}

	}
	@RequestMapping("/feedbackFetch")

	public ModelAndView feedbackFetch(@ModelAttribute("feedback") FeedbackPojo feedbackPojo,
			BindingResult result, HttpServletRequest request, HttpServletResponse response) {

		List<FeedbackPojo> details = new ArrayList<FeedbackPojo>();
		details = usersService.feedbackFetch(feedbackPojo);
		request.setAttribute("details", details);

		if (!details.isEmpty()) {
			return new ModelAndView("FeedbackDetails");
			//return new ModelAndView("Sample1");
		} else {
			return new ModelAndView("Error");
		}

	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public ModelAndView logoutPage(@RequestParam(value = "logout", required = false) String logout,
			HttpServletRequest request, HttpServletResponse response) {

		ModelAndView model = new ModelAndView();
		if (logout != null) {
			HttpSession session = request.getSession(false);
			session.invalidate();
			model.addObject("message", "Logged out successfully.");

		}

		return new ModelAndView("Home");
	}

	@RequestMapping("/donorLogin")

	public ModelAndView donorLogin(@ModelAttribute("command") DonorPojo donorPojo, BindingResult result,
			HttpServletRequest request, HttpServletResponse response) {
		int donorId;
		donorId = usersService.donorLogin(donorPojo);
		
		
        
		if (donorId != 0) {
			request.setAttribute("donorId", donorId);
			List<PostBloodRequirementPojo> requirementList = new ArrayList<PostBloodRequirementPojo>();
			requirementList = usersService.displayRequirements();

			// model.put("studList", studList);
			request.setAttribute("requirementList", requirementList);
			System.out.println(requirementList);

			if (requirementList != null) {
				return new ModelAndView("DonorBooking");
			} else
			{
				 
				return new ModelAndView("Error");
			}
		} else {
			ModelAndView mav = new ModelAndView("DonorLogin");
			mav.addObject("d_error","Invalid credentials"); 
			return mav;
		}

	}

	@RequestMapping("/insertBloodRequirement")

	public ModelAndView insertBloodRequirement(@ModelAttribute("command") PostBloodRequirementPojo requisterPojo,
			BindingResult result) {
		int id;
		System.out.println(requisterPojo.getRequisterName());
		id = usersService.insertBloodRequirement(requisterPojo);
		if (id == 1) {
			return new ModelAndView("PostedInHome");
		} else {
			return new ModelAndView("Error");
		}

	}

	@RequestMapping("/requirementFetch")
	public ModelAndView displayBloodRequirements(HttpServletRequest request, HttpServletResponse response) {
	
		List<PostBloodRequirementPojo> requirementList = new ArrayList<PostBloodRequirementPojo>();
		requirementList = usersService.displayRequirements();

		// model.put("studList", studList);
		request.setAttribute("requirementList", requirementList);
		if (requirementList != null) {
			return new ModelAndView("BloodRequired");
		} else
			return new ModelAndView("Error");
	}

	@RequestMapping("/slotBooking")
	public ModelAndView slotBooking(@ModelAttribute("command") SlotBookingPojo slotBookingPojo, BindingResult result,
			HttpServletRequest request, HttpServletResponse response) {
		//.System.out.println(87958);
		int i = slotBookingPojo.getDonorId();
		System.out.println(i);
		ModelAndView model = new ModelAndView("BookingForm");
		//ModelAndView model = new ModelAndView("Sample");
		model.addObject("slotBookingPojo", slotBookingPojo);
		return model;

	}

	@RequestMapping("/confirmSlot")
	public ModelAndView confirmSlot(@ModelAttribute("command") SlotBookingPojo slotBookingPojo, BindingResult result,
			HttpServletRequest request, HttpServletResponse response) {
		int recipientId, delete;
		System.out.println(slotBookingPojo.getDate());
		recipientId = usersService.confirmSlot(slotBookingPojo);
		if (recipientId != 0) {
			delete = usersService.deleteRequirement(recipientId);
			if (delete != 0) {
				return new ModelAndView("Feedback");
			}

			else {
				return new ModelAndView("Error");
			}

		} else {
			return new ModelAndView("Error");
		}

	}
	@RequestMapping(value = "/loginDonor", method = RequestMethod.GET)
	public ModelAndView loginDonor(	HttpServletRequest request, HttpServletResponse response) {

		ModelAndView model = new ModelAndView();
		return new ModelAndView("DonorLogin");
	}
	@RequestMapping("/feedback")

	public ModelAndView feedback(@ModelAttribute("command") FeedbackPojo feedbackPojo, BindingResult result) {
		int id;
		id = usersService.feedbackEntry(feedbackPojo);
		if (id == 1) {
			return new ModelAndView("Home");
		} else {
			return new ModelAndView("Error");
		}

	}

	@RequestMapping(value = "/registerDonor", method = RequestMethod.GET)
	public ModelAndView registerDonor(	HttpServletRequest request, HttpServletResponse response) {

		ModelAndView model = new ModelAndView();
		return new ModelAndView("DonorRegister");
	}
	@RequestMapping(value = "/registerRecipient", method = RequestMethod.GET)
	public ModelAndView registerRecipient(	HttpServletRequest request, HttpServletResponse response) {

		ModelAndView model = new ModelAndView();
		return new ModelAndView("RegisterUser");
	}
	@RequestMapping(value = "/loginRecipient", method = RequestMethod.GET)
	public ModelAndView loginRecipient(	HttpServletRequest request, HttpServletResponse response) {

		ModelAndView model = new ModelAndView();
		return new ModelAndView("Login");
	}
	@RequestMapping(value = "/homePage", method = RequestMethod.GET)
	public ModelAndView homePage(	HttpServletRequest request, HttpServletResponse response) {

		ModelAndView model = new ModelAndView();
		return new ModelAndView("Home");
	}
	@RequestMapping(value = "/postRequirement", method = RequestMethod.GET)
	public ModelAndView postRequirement(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView model = new ModelAndView();
		return new ModelAndView("PostRequirement");
	}

}
