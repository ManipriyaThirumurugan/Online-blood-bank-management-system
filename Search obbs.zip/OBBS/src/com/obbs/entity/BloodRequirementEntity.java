package com.obbs.entity;

public class BloodRequirementEntity {

}
