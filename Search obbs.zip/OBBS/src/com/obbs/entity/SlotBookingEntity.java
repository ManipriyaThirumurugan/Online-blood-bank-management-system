package com.obbs.entity;

public class SlotBookingEntity {

}
