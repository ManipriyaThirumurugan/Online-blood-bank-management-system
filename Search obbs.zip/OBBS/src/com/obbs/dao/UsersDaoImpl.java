package com.obbs.dao;

import java.util.ArrayList;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.obbs.entity.DonorEntity;
import com.obbs.entity.UsersEntity;
import com.obbs.model.DonorPojo;
import com.obbs.model.RecipientPojo;
import com.obbs.model.UsersPojo;

@Repository("usersDao")
public class UsersDaoImpl implements UsersDao {

	private ArrayList<DonorPojo> details;

	@Override
	public int registerUser(UsersPojo usersPojo) {
		// TODO Auto-generated method stub
		SessionFactory sessionfactory = null;
		Session session = null;

		try {
			sessionfactory = HibernateUtil.getSessionFactory();
			session = sessionfactory.openSession();
			Transaction transaction = session.beginTransaction();

			long contactNumber;

			UsersEntity usersEntity = new UsersEntity();
			System.out.println(usersPojo.getFirstName());

			usersEntity.setFirstName(usersPojo.getFirstName());
			usersEntity.setLastName(usersPojo.getLastName());
			usersEntity.setAge(usersPojo.getAge());
			usersEntity.setGender(usersPojo.getGender());
			contactNumber = (long)usersPojo.getContactNumber();
			usersEntity.setContactNumber(contactNumber);

			usersEntity.setEmail(usersPojo.getEmail());
			usersEntity.setPassword(usersPojo.getPassword());
			usersEntity.setWeight(usersPojo.getWeight());
			usersEntity.setState(usersPojo.getState());
			usersEntity.setArea(usersPojo.getArea());
			usersEntity.setPinCode(usersPojo.getPinCode());
			usersEntity.setBloodGroup(usersPojo.getBloodGroup());

			session.save(usersEntity);
			transaction.commit();
			return 1;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return 0;
	}

	@Override
	public int loginUser(UsersPojo usersPojo) {

		SessionFactory sessionfactory = null;
		Session session = null;
		try {
			sessionfactory = HibernateUtil.getSessionFactory();
			session = sessionfactory.openSession();

			List list = session.createQuery("from UsersEntity").list();

			for (int i = 0; i < list.size(); i++) {
				UsersEntity usersEntity = (UsersEntity) list.get(i);
				if (usersPojo.getEmail().equals(usersEntity.getEmail())
						&& (usersPojo.getPassword().equals(usersEntity.getPassword()))) {
					return 1;
				}

			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return 0;
	}

	@Override
	public int registerDonor(DonorPojo donorPojo) {
		// TODO Auto-generated method stub

		SessionFactory sessionfactory = null;
		Session session = null;

		try {
			sessionfactory = HibernateUtil.getSessionFactory();
			session = sessionfactory.openSession();
			Transaction transaction = session.beginTransaction();

			long contactNumber;

			DonorEntity donorEntity = new DonorEntity();

			donorEntity.setDonorName(donorPojo.getDonorName());
			System.out.println(donorPojo.getDonorName());
			contactNumber =  (donorPojo.getContactNumber());
			donorEntity.setContactNumber(contactNumber);
			donorEntity.setState(donorPojo.getState());
			donorEntity.setArea(donorPojo.getArea());
			donorEntity.setPinCode(donorPojo.getPinCode());
			donorEntity.setBloodGroup(donorPojo.getBloodGroup());

			session.save(donorEntity);
			transaction.commit();
			return 1;
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return 0;
	}

	@Override
	public List donorCheck(RecipientPojo recipientPojo) {
		SessionFactory sessionfactory = null;
		Session session = null;

		List<DonorPojo> details = null;
		details = new ArrayList<DonorPojo>();
		try {
			sessionfactory = HibernateUtil.getSessionFactory();
			session = sessionfactory.openSession();
			List list = session.createQuery("from DonorEntity").list();

			for (int i = 0; i < list.size(); i++) {

				DonorEntity donorEntity = (DonorEntity) list.get(i);
				DonorPojo donorPojo = new DonorPojo();

				if (recipientPojo.getArea().equals(donorEntity.getArea())
						&& (recipientPojo.getBloodGroup().equals(donorEntity.getBloodGroup()))) {

					donorPojo.setId(donorEntity.getId());
					donorPojo.setDonorName(donorEntity.getDonorName());
					donorPojo.setArea(donorEntity.getArea());
					donorPojo.setBloodGroup(donorEntity.getBloodGroup());
					donorPojo.setContactNumber(donorEntity.getContactNumber());
					donorPojo.setPinCode(donorEntity.getPinCode());
					donorPojo.setState(donorEntity.getState());
					details.add(donorPojo);

				}

			}
		} catch (Exception e) {
			System.out.println(e);
		}

		return details;

	}
}
