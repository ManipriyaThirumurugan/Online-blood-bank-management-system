package com.obbs.dao;

import java.util.ArrayList;
import java.util.List;

import com.obbs.model.DonorPojo;
import com.obbs.model.RecipientPojo;
import com.obbs.model.UsersPojo;

public interface UsersDao {

	public int registerUser(UsersPojo usersPojo);

	public int loginUser(UsersPojo usersPojo);

	public int registerDonor(DonorPojo donorPojo);

	public List donorCheck(RecipientPojo recipientPojo);
}
